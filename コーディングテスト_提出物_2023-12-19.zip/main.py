import requests

def get_repo_info(username, repo, token):
	headers = {
		'Authorization': f'token {token}',
		'X-GitHub-Api-Version': '2022-11-28'
	}
	url = f'https://api.github.com/repos/{username}/{repo}'
	response = requests.get(url, headers=headers)
	return response.json()

def set_repo_topics(username, repo, token, topics):
	headers = {
		'Accept': 'application/vnd.github+json',
		'X-GitHub-Api-Version': '2022-11-28',
		'Authorization': f'Bearer {token}'
	}
	url = f'https://api.github.com/repos/{username}/{repo}/topics'
	data = {'names': topics}
	response = requests.put(url, headers=headers, json=data)
	return response.status_code, response.json()

def main():
	# GitHub ユーザー名、リポジトリ名、およびトークンを設定
	username = input("Enter your GitHub username: ")
	repo = input("Enter the repository name: ")
	token = input("Enter your GitHub token: ")

	# リポジトリ情報を取得
	repo_info = get_repo_info(username, repo, token)
	# 主要な開発言語を抽出
	language = repo_info.get('language', {})
	# languageを小文字に変換
	language = language.lower()
	if language:  # language が空でないことを確認
		# 主要な開発言語をトピックに設定
		print("Language is:", language)
		status_code, response_json = set_repo_topics(username, repo, token, [language])
		print("Status code:", status_code)
		print("Response:", response_json)
	else:
		print("No language found for the repository.")

if __name__ == "__main__":
	main()
